const path = require('path');
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);
const miniappsRoot = path.join(__dirname, 'miniapps');

/**
 * Every mini app uses the "@/" alias for its own repo root. Inside
 * miniapps/<id>/, resolve "@/x" to miniapps/<id>/x so the four apps
 * don't clash. Everything else resolves normally (libraries come from
 * Upande Apps' node_modules).
 */
config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName.startsWith('@/')) {
    const rel = path.relative(miniappsRoot, context.originModulePath);
    if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) {
      const id = rel.split(path.sep)[0];
      return context.resolveRequest(context, path.join(miniappsRoot, id, moduleName.slice(2)), platform);
    }
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
