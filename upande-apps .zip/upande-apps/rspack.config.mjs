import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as Repack from '@callstack/repack';
import { findAll, report } from './scripts/miniapp-entries.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Upande Apps compiles every mini app into the one APK.
 *
 * Before building, each mini app repo is cloned into miniapps/<id>
 * (the GitHub Action does this; see README for doing it locally).
 * `@miniapps/<id>` then points at that app's entry (see
 * scripts/miniapp-entries.mjs). If none is found, it points at a
 * placeholder so the build still works.
 */
const placeholder = path.resolve(__dirname, 'src/miniapps/Placeholder.tsx');
const found = findAll(__dirname);
report(__dirname, found).forEach(line => console.log(line));
const miniAppAliases = Object.fromEntries(found.map(r => [`@miniapps/${r.id}$`, r.entry ?? placeholder]));

export default Repack.defineRspackConfig({
  context: __dirname,
  entry: './index.js',
  resolve: {
    ...Repack.getResolveOptions({ enablePackageExports: true }),
    alias: miniAppAliases,
  },
  module: {
    rules: [
      {
        test: /\.[cm]?[jt]sx?$/,
        type: 'javascript/auto',
        use: {
          loader: '@callstack/repack/babel-swc-loader',
          parallel: true,
          options: {},
        },
      },
      ...Repack.getAssetTransformRules(),
    ],
  },
  plugins: [new Repack.RepackPlugin()],
});
