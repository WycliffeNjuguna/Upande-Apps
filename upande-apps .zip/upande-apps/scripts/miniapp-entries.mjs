/**
 * Finds the file to load for each mini app in miniapps/<id>.
 * Shared by rspack.config.mjs and scripts/merge-miniapp-deps.mjs.
 *
 * Order:
 *  1. src/MiniApp.(tsx|jsx|ts|js): a dedicated entry that uses the kit.
 *  2. Whatever the app's index file registers with AppRegistry.registerComponent
 *     or registerRootComponent: the same root React Native would start.
 *  3. App.* at the repo root, then under src/.
 */
import fs from 'node:fs';
import path from 'node:path';

export const MINI_APP_IDS = ['production', 'livestock', 'scp'];
const EXT = ['.tsx', '.ts', '.jsx', '.js'];

function resolveFile(base) {
  if (fs.existsSync(base) && fs.statSync(base).isFile()) return base;
  for (const e of EXT) if (fs.existsSync(base + e)) return base + e;
  for (const e of EXT) if (fs.existsSync(path.join(base, 'index' + e))) return path.join(base, 'index' + e);
  return null;
}

function fromIndexFile(root) {
  let main;
  try {
    main = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).main;
  } catch {}
  if (typeof main === 'string' && main.startsWith('expo-router')) {
    return { expoRouter: true };
  }
  const candidates = [main && !main.includes('node_modules') ? path.join(root, main) : null, 'index', 'src/index']
    .filter(Boolean)
    .map(p => resolveFile(path.isAbsolute(p) ? p : path.join(root, p)))
    .filter(Boolean);
  for (const file of candidates) {
    const src = fs.readFileSync(file, 'utf8');
    const reg =
      src.match(/registerComponent\(\s*[^,]+,\s*\(\)\s*=>\s*([A-Za-z_$][\w$]*)/) ||
      src.match(/registerRootComponent\(\s*([A-Za-z_$][\w$]*)\s*\)/);
    if (!reg) continue;
    const name = reg[1];
    const imp =
      src.match(new RegExp(`import\\s+${name}\\s*(?:,\\s*\\{[^}]*\\})?\\s+from\\s+['"]([^'"]+)['"]`)) ||
      src.match(new RegExp(`(?:const|let|var)\\s+${name}\\s*=\\s*require\\(\\s*['"]([^'"]+)['"]\\s*\\)`));
    if (imp && imp[1].startsWith('.')) {
      const entry = resolveFile(path.resolve(path.dirname(file), imp[1]));
      if (entry) return { entry, via: path.relative(root, file) };
    }
  }
  return {};
}

export function findMiniAppEntry(projectRoot, id) {
  const root = path.join(projectRoot, 'miniapps', id);
  if (!fs.existsSync(root) || fs.readdirSync(root).length === 0) {
    return { id, entry: null, reason: 'code not pulled: check MINIAPPS_TOKEN, the repo name and the branch' };
  }
  for (const e of EXT) {
    const f = path.join(root, 'src', 'MiniApp' + e);
    if (fs.existsSync(f)) return { id, entry: f, how: 'src/MiniApp' };
  }
  const idx = fromIndexFile(root);
  if (idx.entry) return { id, entry: idx.entry, how: `registered in ${idx.via}` };
  for (const dir of ['', 'src']) {
    const f = resolveFile(path.join(root, dir, 'App'));
    if (f && !f.endsWith(`${path.sep}index.js`)) return { id, entry: f, how: 'App file' };
  }
  if (idx.expoRouter) {
    return { id, entry: null, reason: 'Expo Router app: add a src/MiniApp.tsx entry to this repo' };
  }
  const top = fs.readdirSync(root).filter(f => !f.startsWith('.')).slice(0, 12).join(', ');
  return { id, entry: null, reason: `code pulled, but no app entry found (top-level files: ${top})` };
}

export function findAll(projectRoot) {
  return MINI_APP_IDS.map(id => findMiniAppEntry(projectRoot, id));
}

export function report(projectRoot, results) {
  const lines = results.map(r =>
    r.entry
      ? `[upande-apps] ${r.id}: included from ${path.relative(projectRoot, r.entry)} (${r.how})`
      : `[upande-apps] ${r.id}: NOT included, ${r.reason}`,
  );
  return lines;
}
