#!/usr/bin/env node
/**
 * Adds each mini app's dependencies (miniapps/<id>/package.json) to
 * Upande Apps' package.json, because they all compile into one APK.
 *
 * - A package Upande Apps already has keeps Upande Apps' version.
 * - A package only a mini app uses is added with that mini app's version.
 * - If two mini apps want different versions, the first one listed wins.
 * Every disagreement is printed so you can line the versions up.
 *
 * Run after cloning the mini apps and before `npm install`.
 */
import fs from 'node:fs';
import path from 'node:path';
import { findAll, report } from './miniapp-entries.mjs';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const pkgPath = path.join(root, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
const own = { ...pkg.dependencies };
const ids = ['production', 'livestock', 'scp'];

const added = [];
const conflicts = [];
const source = {};

for (const id of ids) {
  const p = path.join(root, 'miniapps', id, 'package.json');
  if (!fs.existsSync(p)) {
    console.log(`- ${id}: not cloned, skipped`);
    continue;
  }
  const deps = JSON.parse(fs.readFileSync(p, 'utf8')).dependencies ?? {};
  for (const [name, version] of Object.entries(deps)) {
    const current = pkg.dependencies[name];
    if (!current) {
      pkg.dependencies[name] = version;
      source[name] = id;
      added.push(`${name}@${version} (${id})`);
    } else if (current !== version) {
      conflicts.push(
        `${name}: ${id} wants ${version}, using ${current} from ${own[name] ? 'Upande Apps' : source[name]}`,
      );
    }
  }
  console.log(`- ${id}: ${Object.keys(deps).length} dependencies read`);
}

pkg.dependencies = Object.fromEntries(Object.entries(pkg.dependencies).sort(([a], [b]) => a.localeCompare(b)));
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');

console.log(`\nAdded ${added.length}:`);
added.forEach(a => console.log(`  + ${a}`));
const lines = report(root, findAll(root));
console.log('\nMini apps in this build:');
lines.forEach(l => console.log('  ' + l));
if (process.env.GITHUB_STEP_SUMMARY) {
  fs.appendFileSync(
    process.env.GITHUB_STEP_SUMMARY,
    '### Mini apps in this build\n' + lines.map(l => '- ' + l.replace('[upande-apps] ', '')).join('\n') + '\n',
  );
}
lines.filter(l => l.includes('NOT included')).forEach(l => console.log(`::warning::${l.replace('[upande-apps] ', '')}`));

if (conflicts.length) {
  console.log(`\nVersion differences (${conflicts.length}). If the build fails, check these first:`);
  conflicts.forEach(c => console.log(`  ! ${c}`));
}
