#!/usr/bin/env node
/**
 * Folds the mini app repos into Upande Apps before a build.
 *
 * For each app in scripts/miniapps.config.json:
 *   1. Clone it into miniapps/<id> (skipped if that folder already exists).
 *   2. Create app/<id>/... route files that point at its app/ folder, so all
 *      of its screens live under /<id> (its root layout becomes /<id>'s layout).
 *   3. Adjust the copy (never the repo): links like '/login' become
 *      '/<id>/login', and `segments[0]` in its layouts becomes `segments[1]`.
 *   4. Merge its libraries into package.json and its native config
 *      (plugins, permissions, URL schemes, kit settings) into
 *      miniapps.generated.json, which app.config.js reads.
 *
 * Usage: node scripts/prepare-miniapps.mjs [--fresh]
 *   --fresh   delete miniapps/ and app/<id>/ first and clone again
 * Env: MINIAPPS_TOKEN  GitHub token, only needed for private repos
 */
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const MINI = path.join(ROOT, 'miniapps');
const APP_DIR = path.join(ROOT, 'app');
const { apps } = JSON.parse(fs.readFileSync(path.join(ROOT, 'scripts/miniapps.config.json'), 'utf8'));
const SHARED_ROUTES = new Set(['mobile-kit']); // the kit links to /mobile-kit/... itself
const SHELL_OWNED_PLUGINS = new Set(['expo-router', 'expo-splash-screen', 'expo-updates']);
const SKIP_DIRS = new Set(['node_modules', '.git', 'android', 'ios', '.expo', 'dist', 'build', 'docs', '__tests__', 'coverage']);
const SRC_EXT = /\.(tsx?|jsx?|mjs|cjs)$/;
// Test and lint tooling some apps list as regular dependencies; not needed in the APK.
const SKIP_DEPS = /^(jest|jest-expo|typescript|eslint.*|prettier|@types\/.*|@testing-library\/.*|react-test-renderer)$/;

const fresh = process.argv.includes('--fresh');
const summary = [];
const log = (...a) => console.log(...a);

// ---------- helpers ----------

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name.startsWith('.') && e.name !== '.') continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (!SKIP_DIRS.has(e.name)) walk(p, out);
    } else out.push(p);
  }
  return out;
}

function clone(app) {
  const dest = path.join(MINI, app.id);
  if (fs.existsSync(dest) && fs.readdirSync(dest).length) {
    log(`  using existing miniapps/${app.id}`);
    return true;
  }
  const token = process.env.MINIAPPS_TOKEN;
  const url = `https://${token ? `x-access-token:${token}@` : ''}github.com/${app.repo}.git`;
  const args = ['clone', '--quiet', '--depth', '1', ...(app.branch ? ['--branch', app.branch] : []), url, dest];
  try {
    execFileSync('git', args, { stdio: ['ignore', 'ignore', 'pipe'] });
    const sha = execFileSync('git', ['-C', dest, 'rev-parse', '--short', 'HEAD']).toString().trim();
    const branch = execFileSync('git', ['-C', dest, 'rev-parse', '--abbrev-ref', 'HEAD']).toString().trim();
    log(`  cloned ${app.repo} @ ${branch} (${sha})`);
    app._ref = `${branch}@${sha}`;
    return true;
  } catch (e) {
    const msg = String(e.stderr || e.message).replace(token || '\u0000', '***').split('\n')[0];
    log(`  ! could not clone ${app.repo}${app.branch ? ` (${app.branch})` : ''}: ${msg}`);
    app._error = `could not pull ${app.repo}${app.branch ? ` @ ${app.branch}` : ''} (private repo needs MINIAPPS_TOKEN, or the name/branch is wrong)`;
    return false;
  }
}

/** Route files in the mini app's app/ folder that become routes under /<id>. */
function routeFiles(appRoot) {
  const dir = path.join(appRoot, 'app');
  return walk(dir)
    .map(f => path.relative(dir, f))
    .filter(rel => SRC_EXT.test(rel) && !rel.endsWith('.d.ts'))
    .filter(rel => !/(^|\/)\+(html|native-intent)\./.test(rel) && !/\+api\.[jt]sx?$/.test(rel))
    .filter(rel => !/\.(test|spec)\.[jt]sx?$/.test(rel));
}

/** First URL segments used by an app's routes, e.g. login, audit, (tabs), home. */
function topSegments(files) {
  const segs = new Set();
  for (const rel of files) {
    const parts = rel.replace(SRC_EXT, '').split('/');
    if (parts[0].startsWith('(')) segs.add(parts[0]);
    const url = parts.filter(p => !p.startsWith('(') && p !== 'index' && p !== '_layout');
    if (url.length && !url[0].startsWith('[') && !url[0].startsWith('+')) segs.add(url[0]);
  }
  for (const s of SHARED_ROUTES) segs.delete(s);
  return [...segs];
}

function writeStubs(app, files) {
  const appRoot = path.join(MINI, app.id);
  let count = 0;
  for (const rel of files) {
    const top = rel.split('/')[0];
    const shared = SHARED_ROUTES.has(top);
    // Shared kit routes go to /mobile-kit once (from the first app that has them).
    const stubPath = shared ? path.join(APP_DIR, rel) : path.join(APP_DIR, app.id, rel);
    if (shared && fs.existsSync(stubPath)) continue;
    const target = path.join(appRoot, 'app', rel).replace(SRC_EXT, '');
    let spec = path.relative(path.dirname(stubPath), target).split(path.sep).join('/');
    if (!spec.startsWith('.')) spec = './' + spec;
    const src = fs.readFileSync(path.join(appRoot, 'app', rel), 'utf8');
    const hasDefault = /export\s+default\b|export\s*\{[^}]*\bas\s+default\b/.test(src);
    const hasNamed = /export\s+(const|let|var|function|class|async\s+function|\{)/.test(src.replace(/export\s+default/g, ''));
    const lines = [`// Generated by scripts/prepare-miniapps.mjs from ${app.repo}. Do not edit.`];
    if (hasNamed) lines.push(`export * from '${spec}';`);
    if (hasDefault) lines.push(`export { default } from '${spec}';`);
    if (!hasNamed && !hasDefault) lines.push(`export * from '${spec}';`);
    fs.mkdirSync(path.dirname(stubPath), { recursive: true });
    fs.writeFileSync(stubPath, lines.join('\n') + '\n');
    count++;
  }
  return count;
}

/** Points the copy's absolute links and segment checks at /<id>. Never touches the repo itself. */
function rewriteLinks(app, segs) {
  const appRoot = path.join(MINI, app.id);
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const segRe = segs.length
    ? new RegExp(`(['"\`])\\/(${segs.map(esc).join('|')})(?=[\\/?#'"\`]|\\$\\{)`, 'g')
    : null;
  const rootRe = /((?:\b(?:push|replace|navigate|dismissTo|reset)\(\s*)|(?:\bhref\s*=\s*\{?\s*)|(?:\bpathname\s*:\s*))(['"`])\/\2/g;
  let links = 0;
  let guards = 0;
  for (const file of walk(appRoot)) {
    if (!SRC_EXT.test(file)) continue;
    const rel = path.relative(appRoot, file);
    if (rel.split(path.sep)[0] === 'kaitet-web') continue;
    let src = fs.readFileSync(file, 'utf8');
    const before = src;
    if (segRe) src = src.replace(segRe, (m, q, seg) => (links++, `${q}/${app.id}/${seg}`));
    src = src.replace(rootRe, (m, pre, q) => (links++, `${pre}${q}/${app.id}${q}`));
    if (rel.startsWith(`app${path.sep}`)) {
      src = src.replace(/\bsegments\[0\]/g, () => (guards++, 'segments[1]'));
    }
    if (src !== before) fs.writeFileSync(file, src);
  }
  return { links, guards };
}

function versionScore(v) {
  const m = String(v).match(/(\d+)\.(\d+)\.?(\d+)?/);
  return m ? Number(m[1]) * 1e8 + Number(m[2]) * 1e4 + Number(m[3] || 0) : -1;
}

// ---------- main ----------

if (fresh) {
  fs.rmSync(MINI, { recursive: true, force: true });
}
for (const app of apps) fs.rmSync(path.join(APP_DIR, app.id), { recursive: true, force: true });
for (const s of SHARED_ROUTES) fs.rmSync(path.join(APP_DIR, s), { recursive: true, force: true });
fs.mkdirSync(MINI, { recursive: true });

const included = [];
for (const app of apps) {
  log(`\n${app.title} (${app.repo})`);
  if (!clone(app)) {
    summary.push(`${app.title}: NOT included, ${app._error}`);
    continue;
  }
  const files = routeFiles(path.join(MINI, app.id));
  if (!files.length) {
    summary.push(`${app.title}: NOT included, no app/ folder (not an Expo Router app)`);
    log('  ! no app/ folder found');
    continue;
  }
  const segs = topSegments(files);
  const stubs = writeStubs(app, files);
  const { links, guards } = rewriteLinks(app, segs);
  log(`  ${stubs} routes under /${app.id}, ${links} links and ${guards} segment checks adjusted`);
  summary.push(`${app.title}: included${app._ref ? ` from ${app._ref}` : ''} (${stubs} routes, ${links} links adjusted)`);
  included.push(app);
}

// ---------- merge libraries ----------

const pkgPath = path.join(ROOT, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
const shellDeps = { ...pkg.dependencies };
const chosen = {};
const differences = [];
for (const app of included) {
  const deps = JSON.parse(fs.readFileSync(path.join(MINI, app.id, 'package.json'), 'utf8')).dependencies ?? {};
  for (const [name, version] of Object.entries(deps)) {
    if (SKIP_DEPS.test(name)) continue;
    if (shellDeps[name]) {
      if (shellDeps[name] !== version) differences.push(`${name}: ${app.id} has ${version}, using Upande Apps' ${shellDeps[name]}`);
      continue;
    }
    const prev = chosen[name];
    if (!prev) chosen[name] = { version, from: app.id };
    else if (prev.version !== version) {
      const win = versionScore(version) > versionScore(prev.version) ? { version, from: app.id } : prev;
      differences.push(`${name}: ${prev.from} has ${prev.version}, ${app.id} has ${version}, using ${win.version}`);
      chosen[name] = win;
    }
  }
}
pkg.dependencies = Object.fromEntries(
  Object.entries({ ...shellDeps, ...Object.fromEntries(Object.entries(chosen).map(([n, c]) => [n, c.version])) }).sort(
    ([a], [b]) => a.localeCompare(b),
  ),
);
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');

// ---------- merge native config ----------

const plugins = [];
const pluginNames = new Set();
const permissions = new Set();
const infoPlist = {};
const schemes = new Set();
let mobileKit;
for (const app of included) {
  const expo = JSON.parse(fs.readFileSync(path.join(MINI, app.id, 'app.json'), 'utf8')).expo ?? {};
  for (const p of expo.plugins ?? []) {
    const name = Array.isArray(p) ? p[0] : p;
    if (typeof name !== 'string' || name.startsWith('.') || SHELL_OWNED_PLUGINS.has(name) || pluginNames.has(name)) continue;
    pluginNames.add(name);
    plugins.push(p);
  }
  for (const perm of expo.android?.permissions ?? []) permissions.add(perm);
  Object.assign(infoPlist, { ...(expo.ios?.infoPlist ?? {}), ...infoPlist });
  for (const s of [].concat(expo.scheme ?? [])) schemes.add(s);
  if (!mobileKit && expo.extra?.mobileKit) {
    const { nativeBaseline, release, _help, ...kit } = expo.extra.mobileKit;
    mobileKit = kit;
  }
}
const generated = {
  apps: included.map(({ id, title, description, accent }) => ({ id, title, description, accent })),
  plugins,
  androidPermissions: [...permissions],
  iosInfoPlist: infoPlist,
  schemes: [...schemes],
  extra: { ...(mobileKit ? { mobileKit } : {}), runtimeSdk: 58 },
};
fs.writeFileSync(path.join(ROOT, 'miniapps.generated.json'), JSON.stringify(generated, null, 2) + '\n');

// ---------- report ----------

log('\nMini apps in this build:');
summary.forEach(s => log(`  - ${s}`));
log(`\nLibraries: ${Object.keys(chosen).length} added from the mini apps.`);
if (differences.length) {
  log(`Version differences (${differences.length}). If the build fails, check these first:`);
  differences.forEach(d => log(`  ! ${d}`));
}
log(`Native: ${plugins.length} plugins, ${permissions.size} permissions, schemes: ${[...schemes].join(', ') || 'none'}`);

if (process.env.GITHUB_STEP_SUMMARY) {
  fs.appendFileSync(
    process.env.GITHUB_STEP_SUMMARY,
    `### Mini apps in this build\n${summary.map(s => `- ${s}`).join('\n')}\n`,
  );
  summary.filter(s => s.includes('NOT included')).forEach(s => log(`::warning::${s}`));
}
