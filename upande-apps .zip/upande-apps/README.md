# Upande Apps

One Expo (SDK 58) app that holds Production, Quality, Packhouse and
Security. Each app keeps its own repository and keeps working as a
standalone app. When Upande Apps is built, it pulls each repo and
compiles it in, so any change to a mini app reaches phones in the next
Upande Apps build.

## How it works

`scripts/miniapps.config.json` lists the mini apps, their repos and
(optionally) branches. Before a build, `scripts/prepare-miniapps.mjs`:

1. Clones each repo into `miniapps/<id>`.
2. Creates `app/<id>/...` route files pointing at that repo's `app/`
   folder, so all its screens live under `/<id>`. Its root layout becomes
   the layout for `/<id>`, so it keeps its own sign-in, providers and
   navigation.
3. Adjusts the copy (never the repo): links like `'/login'` become
   `'/<id>/login'`, and `segments[0]` checks in its layouts become
   `segments[1]`.
4. Merges every app's libraries into `package.json`, and its native
   config (plugins, permissions, URL schemes, kit settings) into
   `miniapps.generated.json`, which `app.config.js` reads.

Other details:
- `metro.config.js` resolves each app's `@/` imports to that app's own folder.
- The kit's screens stay shared at `/mobile-kit`.
- The home screen (`app/index.tsx`) lists the apps that made it into the
  build. Back from an app's first screen returns there.

## Building the APK on GitHub

Push (or run "Build APK" by hand) and download the APK from the run's
Artifacts. The run summary lists which mini apps were included and how
many links were adjusted in each.

The repos are public, so no token is needed. If one becomes private,
add a repo secret `MINIAPPS_TOKEN` with read access to it.

## Running locally

```sh
node scripts/prepare-miniapps.mjs --fresh
npm install --legacy-peer-deps
npx expo install --fix -- --legacy-peer-deps
npx expo run:android
```

`prepare-miniapps` changes `package.json` and `miniapps.generated.json`.
Don't commit those changes; `git checkout package.json miniapps.generated.json`
resets them.

## Libraries

When apps want different versions of a library:

- Upande Apps' version wins for core packages (Expo SDK 58, React Native
  0.88.1, React 19.3, Expo Router, navigation, gestures, Reanimated).
- Otherwise the highest version among the apps wins.
- `expo install --fix` then aligns everything with SDK 58.

Security is on SDK 54 in its repo, so inside Upande Apps it runs on
SDK 58 libraries. Test its screens carefully, and upgrade the repo to
SDK 58 when you can.

## Things to know

- Each app still has its own sign-in screen. One sign-in for all four can
  come later through the mobile kit.
- All four apps share one device storage space. If two apps save data
  under the same key name (for example a session token), they'll share it.
- Each app's own over-the-air updates and APK self-update are not used
  inside Upande Apps (`updates.enabled` is false).
- Not carried over from the repos: their release-signing plugin (the APK
  is signed with the default test key) and Packhouse's `patches/` for
  expo-updates.
- Before publishing to the Play Store, add your own signing key.
