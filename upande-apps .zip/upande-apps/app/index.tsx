import { useRouter, type Href } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MINI_APPS } from '../src/miniapps';
import { colors, space } from '../src/theme';

export default function Home() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    SplashScreen.hideAsync().catch(() => {});
  }, []);

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <View style={[styles.header, { paddingTop: insets.top + space.lg }]}>
        <Text style={styles.brand}>Upande Apps</Text>
        <Text style={styles.lede}>Choose an app to open</Text>
      </View>

      <ScrollView contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + space.xl }]}>
        {MINI_APPS.length === 0 ? (
          <Text style={styles.empty}>
            No apps were included in this build. Run the build again with the mini app repos available.
          </Text>
        ) : null}

        {MINI_APPS.map(app => (
          <Pressable
            key={app.id}
            accessibilityRole="button"
            accessibilityLabel={`Open ${app.title}`}
            onPress={() => router.push(`/${app.id}` as Href)}
            style={({ pressed }) => [styles.tile, pressed && styles.tilePressed]}>
            <View style={[styles.band, { backgroundColor: app.accent }]} />
            <View style={styles.tileBody}>
              <Text style={styles.tileTitle}>{app.title}</Text>
              <Text style={styles.tileDesc}>{app.description}</Text>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.ground },
  header: {
    backgroundColor: colors.canopy,
    paddingHorizontal: space.lg,
    paddingBottom: space.xl,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  brand: { fontSize: 30, lineHeight: 36, fontWeight: '700', letterSpacing: -0.5, color: colors.onCanopy },
  lede: { fontSize: 16, lineHeight: 23, color: colors.onCanopy, opacity: 0.85, marginTop: space.xs },
  list: { padding: space.lg, gap: space.md, maxWidth: 640, width: '100%', alignSelf: 'center' },
  empty: { fontSize: 16, lineHeight: 23, color: colors.inkMuted },
  tile: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.line,
  },
  tilePressed: { opacity: 0.9 },
  band: { width: 10 },
  tileBody: { flex: 1, padding: space.md, paddingVertical: space.lg },
  tileTitle: { fontSize: 20, lineHeight: 26, fontWeight: '600', color: colors.ink },
  tileDesc: { fontSize: 16, lineHeight: 23, color: colors.inkMuted, marginTop: 2 },
});
