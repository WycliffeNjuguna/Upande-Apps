/**
 * Gradle settings for the combined APK (same values the mini app repos use).
 * Four apps in one build needs the extra memory.
 */
const { withGradleProperties } = require('expo/config-plugins');

const PROPERTIES = {
  'org.gradle.jvmargs': '-Xmx4096m -XX:MaxMetaspaceSize=1024m -XX:+HeapDumpOnOutOfMemoryError -Dfile.encoding=UTF-8',
  reactNativeArchitectures: 'armeabi-v7a,arm64-v8a',
};

module.exports = function withBuildTuning(config) {
  return withGradleProperties(config, cfg => {
    for (const [key, value] of Object.entries(PROPERTIES)) {
      cfg.modResults = cfg.modResults.filter(item => !(item.type === 'property' && item.key === key));
      cfg.modResults.push({ type: 'property', key, value });
    }
    return cfg;
  });
};
