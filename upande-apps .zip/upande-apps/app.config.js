/**
 * Upande Apps native config. The mini apps' native needs (plugins,
 * permissions, URL schemes, kit settings) are merged in from
 * miniapps.generated.json, which `npm run prepare-miniapps` writes.
 */
const generated = require('./miniapps.generated.json');

module.exports = () => ({
  name: 'Upande Apps',
  slug: 'upande-apps',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  userInterfaceStyle: 'light',
  newArchEnabled: true,
  // Keeps each mini app's own deep links and sign-in redirects working.
  scheme: ['upandeapps', ...generated.schemes],
  ios: {
    supportsTablet: true,
    bundleIdentifier: 'com.upande.apps',
    infoPlist: generated.iosInfoPlist,
  },
  android: {
    package: 'com.upande.apps',
    adaptiveIcon: {
      backgroundColor: '#E6F4FE',
      foregroundImage: './assets/android-icon-foreground.png',
      backgroundImage: './assets/android-icon-background.png',
      monochromeImage: './assets/android-icon-monochrome.png',
    },
    permissions: generated.androidPermissions,
    predictiveBackGestureEnabled: false,
  },
  web: { favicon: './assets/favicon.png' },
  plugins: [
    './plugins/withBuildTuning',
    'expo-router',
    ['expo-splash-screen', { backgroundColor: '#1E4A3A', image: './assets/icon.png', imageWidth: 160 }],
    ...generated.plugins,
  ],
  // One APK, no separate over-the-air updates (each mini app's own OTA is switched off).
  updates: { enabled: false },
  extra: generated.extra,
});
