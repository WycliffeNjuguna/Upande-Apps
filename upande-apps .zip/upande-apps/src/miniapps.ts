import generated from '../miniapps.generated.json';

export interface MiniApp {
  id: string;
  title: string;
  description: string;
  accent: string;
}

/** The mini apps compiled into this build (written by scripts/prepare-miniapps.mjs). */
export const MINI_APPS: MiniApp[] = generated.apps as MiniApp[];
