export const colors = {
  ground: '#EEF2EC',
  surface: '#FFFFFF',
  ink: '#16332A',
  inkMuted: '#5A6B61',
  line: '#D3DCD2',
  canopy: '#1E4A3A',
  onCanopy: '#E7F0EA',
};

export const space = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };
