/**
 * @format
 */

import React from 'react';
import ReactTestRenderer from 'react-test-renderer';
import App from '../src/App';

jest.mock('@react-native-async-storage/async-storage', () =>
  require('@react-native-async-storage/async-storage/jest/async-storage-mock'),
);
jest.mock('react-native-safe-area-context', () =>
  require('react-native-safe-area-context/jest/mock').default,
);

beforeEach(() => {
  globalThis.fetch = jest.fn(() => Promise.reject(new Error('offline'))) as jest.Mock;
});

test('renders the sign-in screen when there is no session', async () => {
  let tree: ReactTestRenderer.ReactTestRenderer | undefined;
  await ReactTestRenderer.act(async () => {
    tree = ReactTestRenderer.create(<App />);
  });
  const json = JSON.stringify(tree!.toJSON());
  expect(json).toContain('Upande Apps');
  expect(json).toContain('Kaitet');
});
