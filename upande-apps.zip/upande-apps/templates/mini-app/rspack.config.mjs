import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import * as Repack from '@callstack/repack';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);
const pkg = require('./package.json');

/**
 * Mini app config: copy into the root of upande-production-mobile,
 * upande-livestock-mobile or upande-scp-mobile and set MINI_APP_NAME.
 *
 * MINI_APP_NAME must equal `remoteName` for this app in Upande Apps
 * (src/config/catalog.ts): production | livestock | scp
 *
 * The same repo still builds a standalone app (index.js) for local
 * development; Upande Apps only loads the "./App" module it exposes.
 */
const MINI_APP_NAME = 'production';

// Must match the shell's shared list. Never eager in a mini app: the shell provides them.
const SHARED = [
  'react',
  'react-native',
  'react-native-safe-area-context',
  'react-native-screens',
  '@react-navigation/native',
  '@react-navigation/native-stack',
  '@react-native-async-storage/async-storage',
  // 'upande-mobile-kit',
];

const shared = Object.fromEntries(
  SHARED.filter(name => pkg.dependencies?.[name]).map(name => [
    name,
    { singleton: true, eager: false, requiredVersion: pkg.dependencies[name] },
  ]),
);

export default Repack.defineRspackConfig({
  context: __dirname,
  entry: './index.js',
  resolve: {
    ...Repack.getResolveOptions({ enablePackageExports: true }),
  },
  output: {
    // Chunks are fetched relative to mf-manifest.json, so the release can live in any folder.
    uniqueName: `upande-${MINI_APP_NAME}`,
  },
  module: {
    rules: [
      {
        test: /\.[cm]?[jt]sx?$/,
        type: 'javascript/auto',
        use: {
          loader: '@callstack/repack/babel-swc-loader',
          parallel: true,
          options: {},
        },
      },
      // Inline images/fonts into the remote so they arrive with the update.
      ...Repack.getAssetTransformRules({ inline: true }),
    ],
  },
  plugins: [
    new Repack.RepackPlugin(),
    new Repack.plugins.ModuleFederationPluginV2({
      name: MINI_APP_NAME,
      filename: `${MINI_APP_NAME}.container.js.bundle`,
      exposes: {
        './App': './src/MiniApp.tsx',
      },
      shared,
      dts: false,
    }),
  ],
});
