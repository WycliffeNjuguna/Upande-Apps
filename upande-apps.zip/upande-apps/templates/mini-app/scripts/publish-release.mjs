#!/usr/bin/env node
/**
 * Copies a built mini app into a release repo checkout and updates its manifest.json.
 *
 *   node scripts/publish-release.mjs \
 *     --app production --version 2.4.1 --dist dist --repo ../release-repo \
 *     --min-shell 1.0.0 --rollout 100 --notes "Faster grading screen"
 *
 * The current release becomes `previous`, so a staged rollout (rollout < 100)
 * keeps everyone else on the last version, and you can roll back by
 * publishing with --rollout 0.
 */
import fs from 'node:fs';
import path from 'node:path';

const args = Object.fromEntries(
  process.argv.slice(2).reduce((acc, cur, i, all) => {
    if (cur.startsWith('--')) acc.push([cur.slice(2), all[i + 1]]);
    return acc;
  }, []),
);
for (const k of ['app', 'version', 'dist', 'repo']) {
  if (!args[k]) {
    console.error(`Missing --${k}`);
    process.exit(1);
  }
}

const rollout = Math.max(0, Math.min(100, Number(args.rollout ?? 100)));
const manifestPath = path.join(args.repo, 'manifest.json');
const old = fs.existsSync(manifestPath) ? JSON.parse(fs.readFileSync(manifestPath, 'utf8')) : null;

const platforms = {};
for (const platform of ['android', 'ios']) {
  const src = path.join(args.dist, platform);
  if (!fs.existsSync(path.join(src, 'mf-manifest.json'))) continue;
  const rel = path.posix.join('builds', args.version, platform);
  const dest = path.join(args.repo, rel);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.mkdirSync(dest, { recursive: true });
  for (const f of fs.readdirSync(src)) {
    if (!f.endsWith('.map')) fs.copyFileSync(path.join(src, f), path.join(dest, f));
  }
  platforms[platform] = { entry: `${rel}/mf-manifest.json` };
}
if (!Object.keys(platforms).length) {
  console.error(`No builds found in ${args.dist}/<platform>/mf-manifest.json`);
  process.exit(1);
}

const current = {
  version: args.version,
  ...(args['min-shell'] ? { minShellVersion: args['min-shell'] } : {}),
  platforms,
};
const previous =
  old && old.version !== args.version
    ? { version: old.version, minShellVersion: old.minShellVersion, platforms: old.platforms }
    : old?.previous;

const manifest = {
  schema: 1,
  miniApp: args.app,
  ...current,
  rollout,
  ...(previous ? { previous } : {}),
  ...(args.notes ? { notes: args.notes } : {}),
  publishedAt: new Date().toISOString(),
};
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
console.log(`Published ${args.app} ${args.version} (${Object.keys(platforms).join(', ')}) at ${rollout}% to ${args.repo}`);
