/**
 * Entry point Upande Apps loads (exposed as "./App" in rspack.config.mjs).
 *
 * Wrap your existing root navigator here. Two rules:
 *  1. Use NavigationIndependentTree so this app's navigation never collides
 *     with the shell's or another mini app's.
 *  2. Get the user, farm and ERP access from `kit`, not from your own login.
 */
import React, { createContext, useContext, useEffect } from 'react';
import { BackHandler, Pressable, StyleSheet, Text, View } from 'react-native';
import {
  NavigationContainer,
  NavigationIndependentTree,
  useNavigation,
} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// Once the contract moves into the kit:  import type { MiniAppProps, UpandeKit } from 'upande-mobile-kit';
import type { MiniAppProps, UpandeKit } from './kit-types';

const KitContext = createContext<UpandeKit | null>(null);

export function useKit(): UpandeKit {
  const kit = useContext(KitContext);
  if (!kit) {
    throw new Error('useKit must be used inside the mini app root');
  }
  return kit;
}

const Stack = createNativeStackNavigator();

function HomeScreen() {
  const kit = useKit();
  const navigation = useNavigation();

  // Android back on the first screen leaves the mini app.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (navigation.canGoBack()) {
        return false;
      }
      kit.exit();
      return true;
    });
    return () => sub.remove();
  }, [kit, navigation]);

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Production</Text>
      <Text style={styles.body}>
        {kit.user.fullName} at {kit.tenant.name}
      </Text>
      <Pressable accessibilityRole="button" onPress={kit.exit} style={styles.button}>
        <Text style={styles.buttonLabel}>Back to Upande Apps</Text>
      </Pressable>
    </View>
  );
}

export default function MiniApp({ kit }: MiniAppProps) {
  return (
    <KitContext.Provider value={kit}>
      <NavigationIndependentTree>
        <NavigationContainer>
          <Stack.Navigator>
            <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Production' }} />
          </Stack.Navigator>
        </NavigationContainer>
      </NavigationIndependentTree>
    </KitContext.Provider>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 24 },
  title: { fontSize: 24, fontWeight: '700' },
  body: { fontSize: 16 },
  button: { marginTop: 12, paddingVertical: 12, paddingHorizontal: 20, borderRadius: 10, backgroundColor: '#2F7D4F' },
  buttonLabel: { color: '#fff', fontWeight: '600', fontSize: 16 },
});
