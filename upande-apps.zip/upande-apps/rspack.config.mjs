import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import * as Repack from '@callstack/repack';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);
const pkg = require('./package.json');

/**
 * Upande Apps — the host ("shell") of the super app.
 *
 * Mini apps (Production, Livestock, SCP) are NOT listed here. They are
 * registered at runtime from their release manifests (see
 * src/services/federation.ts), which is what lets each one ship updates
 * independently of this binary.
 *
 * Everything in `shared` is provided by the shell as a singleton. Mini apps
 * must declare the same packages as shared with `eager: false` and must not
 * bundle their own copies. Adding a package with native code here requires a
 * new store release of Upande Apps.
 */
const shared = Object.fromEntries(
  [
    'react',
    'react-native',
    'react-native-safe-area-context',
    'react-native-screens',
    '@react-navigation/native',
    '@react-navigation/native-stack',
    '@react-native-async-storage/async-storage',
    // 'upande-mobile-kit',  // enable once the kit is added as a dependency
  ].map(name => [
    name,
    {
      singleton: true,
      eager: true,
      requiredVersion: pkg.dependencies[name],
    },
  ]),
);

export default Repack.defineRspackConfig({
  context: __dirname,
  entry: './index.js',
  resolve: {
    ...Repack.getResolveOptions({ enablePackageExports: true }),
  },
  module: {
    rules: [
      {
        test: /\.[cm]?[jt]sx?$/,
        type: 'javascript/auto',
        use: {
          loader: '@callstack/repack/babel-swc-loader',
          parallel: true,
          options: {},
        },
      },
      ...Repack.getAssetTransformRules(),
    ],
  },
  plugins: [
    new Repack.RepackPlugin(),
    new Repack.plugins.ModuleFederationPluginV2({
      name: 'upandeApps',
      remotes: {},
      shared,
      dts: false,
    }),
  ],
});
