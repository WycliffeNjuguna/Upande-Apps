import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as Repack from '@callstack/repack';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Upande Apps compiles every mini app into the one APK.
 *
 * Before building, each mini app repo is cloned into miniapps/<id>
 * (the GitHub Action does this; see README for doing it locally).
 * `@miniapps/<id>` then points at that repo's entry file. If a repo
 * isn't there, it points at a placeholder so the build still works.
 */
const MINI_APP_IDS = ['production', 'livestock', 'scp'];

// First match wins. Add src/MiniApp.tsx to a repo to give it a
// dedicated entry that uses the shell's kit; otherwise its normal App is used.
const ENTRY_CANDIDATES = [
  'src/MiniApp.tsx', 'src/MiniApp.jsx', 'src/MiniApp.js',
  'App.tsx', 'App.jsx', 'App.js',
  'src/App.tsx', 'src/App.jsx', 'src/App.js',
];

const placeholder = path.resolve(__dirname, 'src/miniapps/Placeholder.tsx');

const miniAppAliases = Object.fromEntries(
  MINI_APP_IDS.map(id => {
    const root = path.resolve(__dirname, 'miniapps', id);
    const entry = ENTRY_CANDIDATES.map(f => path.join(root, f)).find(f => fs.existsSync(f));
    console.log(`[upande-apps] ${id}: ${entry ? path.relative(__dirname, entry) : 'not included (placeholder)'}`);
    return [`@miniapps/${id}$`, entry ?? placeholder];
  }),
);

export default Repack.defineRspackConfig({
  context: __dirname,
  entry: './index.js',
  resolve: {
    ...Repack.getResolveOptions({ enablePackageExports: true }),
    alias: miniAppAliases,
  },
  module: {
    rules: [
      {
        test: /\.[cm]?[jt]sx?$/,
        type: 'javascript/auto',
        use: {
          loader: '@callstack/repack/babel-swc-loader',
          parallel: true,
          options: {},
        },
      },
      ...Repack.getAssetTransformRules(),
    ],
  },
  plugins: [new Repack.RepackPlugin()],
});
