# Upande Apps

The Upande super app: one APK that holds Production, Livestock and Scouting.
Each mini app keeps its own private repository. When Upande Apps is built,
it pulls each mini app's code from one chosen branch and compiles it in.

Any change to a mini app reaches phones in the next Upande Apps build.

## How it fits together

```
upande-apps (this repo)
├── src/                     shell: sign-in, home screen, kit
├── miniapps/                filled at build time, not committed
│   ├── production/  ← st-i-ve/st-i-ve-upande-production-mobile @ main
│   ├── livestock/   ← st-i-ve/upande-livestock @ kaitet
│   └── scp/         ← upandeltd/Upande-Scout @ kaitet
└── .github/workflows/build-apk.yml
```

Repos and branches are set at the top of `.github/workflows/build-apk.yml`.

When someone opens Upande Apps they choose their farm, sign in with that
farm's Frappe/ERPNext account, and see only that farm's mini apps
(set in `src/config/tenants.ts`). A crash inside one mini app is caught
on its own screen; the others are unaffected.

## Building the APK on GitHub

1. Create a GitHub token that can read all three mini app repos. They're
   under two accounts (st-i-ve and upandeltd), so use a classic token with
   the `repo` scope from an account that has access to both.
2. In this repo: Settings → Secrets and variables → Actions → New secret,
   named `MINIAPPS_TOKEN`.
3. Push, or run the "Build APK" workflow by hand. Download the APK from
   the run's Artifacts.

Without the token the APK still builds; the mini app tiles show
"Not in this build".

## How each mini app is found

For each mini app, the first of these files that exists is used:

1. `src/MiniApp.tsx` (or `.jsx` / `.js`): a dedicated entry that gets the
   shell's `kit` (user, farm, ERP client, `exit()`). See `src/kit/types.ts`.
2. `App.tsx` / `App.jsx` / `App.js`, then the same under `src/`: the
   app's normal root, used as-is.

So the apps work without any changes at first, including their own sign-in
screens. Moving each to a `src/MiniApp.tsx` that uses `kit` lets users sign
in once, in Upande Apps.

## Libraries

All three apps become one APK, so they share one set of libraries.
`scripts/merge-miniapp-deps.mjs` adds each mini app's libraries to this
project before installing:

- A library Upande Apps already has keeps Upande Apps' version
  (React Native 0.88.1, React 19.3, React Navigation 7).
- A library only a mini app uses is added with the mini app's version.
- Every version difference is printed in the build log.

If the build fails, check that list first. The usual fixes are updating
a library in the mini app repo to a version that supports React Native
0.88, or making two mini apps agree on one version.

Things the script can't carry over, which you add here if a mini app
needs them:

- Babel plugins (e.g. `react-native-reanimated/plugin`) and import
  aliases from a mini app's `babel.config.js` or `tsconfig.json`.
- Native setup steps a library documents (permissions in
  `AndroidManifest.xml`, fonts, Google services files).

## Running locally

```sh
git clone -b main  <production repo> miniapps/production
git clone -b kaitet <livestock repo> miniapps/livestock
git clone -b kaitet <scout repo>     miniapps/scp
node scripts/merge-miniapp-deps.mjs
npm install --legacy-peer-deps
npm start            # Re.Pack dev server
npm run android
```

Checks: `npm run typecheck`, `npm test`.

## Before going live

- Fill in the empty `erpUrl` values (Mutara, Altura) in
  `src/config/tenants.ts` and confirm the others are the live sites.
- Replace the default test signing key with your own release key before
  publishing to the Play Store.
- Point `ErrorBoundary.componentDidCatch` at your crash reporter.
