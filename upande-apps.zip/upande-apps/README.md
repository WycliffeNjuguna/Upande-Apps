# Upande Apps

The Upande super app. One store listing that hosts Production, Livestock and
Scouting as mini apps. Each mini app keeps its own repository and ships
updates on its own schedule, without a new store release of Upande Apps.

Built with React Native 0.88, Re.Pack 5 (Rspack) and Module Federation 2.

## How it fits together

```
upandeltd/upande-apps                  this repo: the shell (store binary)
upandeltd/upande-mobile-kit            shared contract + helpers (src/kit/types.ts moves here)
upandeltd/upande-production-mobile  ─┐
upandeltd/upande-livestock-mobile    ├─ mini apps: each exposes "./App"
upandeltd/upande-scp-mobile         ─┘
upandeltd/upande-<app>-<client>-releases   built bundles + manifest.json
upandeltd/upande-apps-config               tenants.json: farms and their mini apps
```

When someone opens Upande Apps:

1. It reads `tenants.json` to list farms (cached for offline use).
2. They sign in with their farm's Frappe/ERPNext account.
3. The home screen reads `manifest.json` from each mini app's release repo
   for that farm, picks the right version (staged rollout, minimum shell
   version) and shows it.
4. Tapping a mini app registers its container with Module Federation and
   loads `./App`, passing it the `kit` (user, farm, ERP client, `exit()`).
5. The build that loaded is remembered, so the app still opens offline.

A crash inside a mini app is caught and shown on its own screen; the other
mini apps are unaffected.

## Running the shell

```sh
npm install
cd ios && bundle install && bundle exec pod install && cd ..
npm start            # Re.Pack dev server (replaces Metro)
npm run android      # or: npm run ios
```

Checks: `npm run typecheck`, `npm test`.

## Onboarding a mini app repo

Do this once in each of upande-production-mobile, upande-livestock-mobile
and upande-scp-mobile:

1. Move the repo to Re.Pack: `npx @callstack/repack-init@5.4.3 -b rspack`.
2. Replace its `rspack.config.mjs` with `templates/mini-app/rspack.config.mjs`
   and set `MINI_APP_NAME` (`production`, `livestock` or `scp`).
3. Add `src/MiniApp.tsx` (see `templates/mini-app/src/MiniApp.tsx`) that wraps
   the existing root navigator and takes user, farm and ERP access from `kit`.
4. Match the shell's versions of every package in the shared list in
   `rspack.config.mjs` (react, react-native, navigation, screens, safe area,
   async storage).
5. Copy `templates/mini-app/scripts/publish-release.mjs` and
   `templates/mini-app/.github/workflows/publish-mini-app.yml`, set
   `MINI_APP` and `CLIENTS`, and add the `RELEASES_TOKEN` secret.
6. Tag a release (`git tag v2.4.1 && git push --tags`).

Client branches (mutara, kaitet, …) are no longer needed: one build serves
every farm, and differences come from `kit.tenant` and `tenants.json`.

## Shipping updates

| Change | What you do | Store release? |
| --- | --- | --- |
| Fix or feature in a mini app | Tag the mini app repo | No |
| Staged rollout | Run the workflow by hand with `rollout` 10, 50, 100 | No |
| Roll back | Re-run with `rollout` 0 (everyone gets `previous`) | No |
| Give a farm another mini app | Edit `tenants.json` in upande-apps-config | No |
| New native module, or a shared package upgrade | Add it here, release Upande Apps, then raise `MIN_SHELL_VERSION` in the mini app | Yes |

Users outside a staged rollout stay on `previous`. A build whose
`minShellVersion` is newer than the installed shell is never loaded; users
see a prompt to update from the store.

## Rules that keep it working

- Native code lives only in the shell. A mini app can only use native
  modules the shell already ships.
- Shared packages are singletons provided by the shell. Mini apps declare
  them with `eager: false` and the same versions.
- `src/kit/types.ts` is the contract. Move it into upande-mobile-kit and bump
  the kit's major version when it changes in a breaking way.
- Each mini app uses `NavigationIndependentTree` and calls `kit.exit()` to
  return home.

## Before going live

- Fill in the empty `erpUrl` values (Mutara, Altura) and confirm the others
  are the live sites, in both `templates/config-repo/tenants.json` and
  `src/config/tenants.ts`.
- Create `upandeltd/upande-apps-config` with `tenants.json`, and the release
  repos for any app/client pair that doesn't have one yet.
- Turn on Re.Pack code signing so the shell only runs bundles signed by
  your CI key.
- Test the full path on a real device: publish a build, open it, put the
  phone in airplane mode and open it again.
- Point `ErrorBoundary.componentDidCatch` at your crash reporter.
