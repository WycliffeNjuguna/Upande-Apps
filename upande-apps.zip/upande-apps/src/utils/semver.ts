/** Minimal x.y.z comparison; pre-release tags are ignored. */
export function compareVersions(a: string, b: string): number {
  const pa = a.split('-')[0].split('.').map(n => parseInt(n, 10) || 0);
  const pb = b.split('-')[0].split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) {
      return d > 0 ? 1 : -1;
    }
  }
  return 0;
}

export function meetsMinimum(version: string, minimum?: string): boolean {
  return !minimum || compareVersions(version, minimum) >= 0;
}

/** Stable 0–99 bucket per user and mini app, for staged rollouts. */
export function rolloutBucket(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) % 100;
}
