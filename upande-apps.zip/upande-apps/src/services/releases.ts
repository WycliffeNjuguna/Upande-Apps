import { Platform } from 'react-native';
import { releaseBaseUrl, type MiniAppDefinition } from '../config/catalog';
import { SHELL_VERSION } from '../config/env';
import type { Tenant } from '../config/tenants';
import { fetchJson } from '../utils/net';
import { meetsMinimum, rolloutBucket } from '../utils/semver';
import { readJson, writeJson } from './storage';

/**
 * manifest.json at the root of each release repo, written by the mini app's CI.
 * See templates/release-repo/manifest.example.json.
 */
interface ReleaseBuild {
  version: string;
  /** Lowest Upande Apps version this build runs on. */
  minShellVersion?: string;
  /** Per platform: path (relative to the repo root) or URL of the build's mf-manifest.json. */
  platforms: { android?: { entry: string }; ios?: { entry: string } };
}

export interface ReleaseManifest extends ReleaseBuild {
  schema: 1;
  miniApp: string;
  /** 0–100: share of users who get `version`. Others get `previous`. Default 100. */
  rollout?: number;
  previous?: ReleaseBuild;
  notes?: string;
}

export interface ResolvedRelease {
  version: string;
  entryUrl: string;
  /** Where this came from: fresh from the release repo, or the last good copy on the device. */
  source: 'network' | 'cache';
}

export type ReleaseProblem =
  | { kind: 'needs-shell-update'; required: string }
  | { kind: 'unavailable'; detail: string };

export class ReleaseError extends Error {
  problem: ReleaseProblem;
  constructor(problem: ReleaseProblem) {
    super(problem.kind === 'needs-shell-update' ? `Needs Upande Apps ${problem.required}` : problem.detail);
    this.problem = problem;
  }
}

const cacheKey = (app: MiniAppDefinition, tenant: Tenant) => `release:${tenant.id}:${app.id}`;

function pickBuild(m: ReleaseManifest, seed: string): ReleaseBuild {
  const rollout = m.rollout ?? 100;
  if (rollout < 100 && m.previous && rolloutBucket(seed) >= rollout) {
    return m.previous;
  }
  return m;
}

function toResolved(build: ReleaseBuild, base: string): ResolvedRelease | null {
  const entry = build.platforms[Platform.OS as 'android' | 'ios']?.entry;
  if (!entry) {
    return null;
  }
  return {
    version: build.version,
    entryUrl: /^https?:\/\//.test(entry) ? entry : base + entry.replace(/^\/+/, ''),
    source: 'network',
  };
}

/**
 * Works out which build of a mini app this user should run:
 * newest compatible build from the release repo, honouring staged rollout,
 * falling back to the last build that loaded on this device when offline.
 */
export async function resolveRelease(
  app: MiniAppDefinition,
  tenant: Tenant,
  userEmail: string,
): Promise<ResolvedRelease> {
  const base = releaseBaseUrl(app, tenant.id);
  let manifest: ReleaseManifest | null = null;
  try {
    // Cache-busting query: raw.githubusercontent.com caches for a few minutes.
    manifest = await fetchJson<ReleaseManifest>(`${base}manifest.json?t=${Date.now()}`);
  } catch {
    manifest = null;
  }

  if (manifest) {
    const build = pickBuild(manifest, `${userEmail}:${app.id}`);
    if (!meetsMinimum(SHELL_VERSION, build.minShellVersion)) {
      // Prefer the previous build if it still runs on this shell.
      if (manifest.previous && meetsMinimum(SHELL_VERSION, manifest.previous.minShellVersion)) {
        const prev = toResolved(manifest.previous, base);
        if (prev) {
          return prev;
        }
      }
      throw new ReleaseError({ kind: 'needs-shell-update', required: build.minShellVersion! });
    }
    const resolved = toResolved(build, base);
    if (resolved) {
      return resolved;
    }
  }

  const cached = await readJson<ResolvedRelease>(cacheKey(app, tenant));
  if (cached) {
    return { ...cached, source: 'cache' };
  }
  throw new ReleaseError({
    kind: 'unavailable',
    detail: manifest
      ? `${app.title} has no ${Platform.OS} build published for ${tenant.name}.`
      : `${app.title} hasn’t been downloaded yet. Connect to the internet to open it the first time.`,
  });
}

/** Call after a build has loaded successfully, so it can be used offline. */
export async function rememberGoodRelease(app: MiniAppDefinition, tenant: Tenant, r: ResolvedRelease) {
  await writeJson(cacheKey(app, tenant), { ...r, source: 'network' });
}
