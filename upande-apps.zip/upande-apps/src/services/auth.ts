import type { Tenant } from '../config/tenants';
import type { KitUser } from '../kit/types';
import { fetchJson } from '../utils/net';
import { readJson, removeKey, writeJson } from './storage';

const SESSION_KEY = 'shell:session';

export interface Session {
  tenantId: string;
  user: KitUser;
}

export class SignInError extends Error {}

/** Signs in to the farm's Frappe site. The session cookie is kept by the OS networking layer. */
export async function signIn(tenant: Tenant, email: string, password: string): Promise<Session> {
  if (!tenant.erpUrl) {
    throw new SignInError(`${tenant.name} has no ERP address set up yet. Ask Upande support to add it.`);
  }
  let fullName = email;
  try {
    const r = await fetchJson<{ message?: string; full_name?: string }>(
      `${tenant.erpUrl}/api/method/login`,
      {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ usr: email.trim(), pwd: password }),
      },
    );
    fullName = r.full_name || email;
  } catch (e: any) {
    if (e?.status === 401) {
      throw new SignInError('That email and password don’t match an account on this farm.');
    }
    throw new SignInError(`Couldn’t reach ${tenant.name}. Check your connection and try again.`);
  }
  const session: Session = { tenantId: tenant.id, user: { email: email.trim(), fullName } };
  await writeJson(SESSION_KEY, session);
  return session;
}

/** Restores a saved session if the farm's site still recognises the cookie. Offline keeps the session. */
export async function restoreSession(tenants: Tenant[]): Promise<Session | null> {
  const saved = await readJson<Session>(SESSION_KEY);
  const tenant = saved && tenants.find(t => t.id === saved.tenantId);
  if (!saved || !tenant) {
    return null;
  }
  try {
    const r = await fetchJson<{ message?: string }>(
      `${tenant.erpUrl}/api/method/frappe.auth.get_logged_user`,
      { credentials: 'include', headers: { Accept: 'application/json' } },
    );
    return r.message && r.message !== 'Guest' ? saved : null;
  } catch (e: any) {
    // 401/403 means the session expired; anything else is probably offline.
    return e?.status === 401 || e?.status === 403 ? null : saved;
  }
}

export async function signOut(tenant: Tenant | undefined): Promise<void> {
  await removeKey(SESSION_KEY);
  if (tenant?.erpUrl) {
    try {
      await fetch(`${tenant.erpUrl}/api/method/logout`, { method: 'POST', credentials: 'include' });
    } catch {
      // already signed out locally
    }
  }
}
