import type { ComponentType } from 'react';
import { loadRemote, registerRemotes } from '@module-federation/enhanced/runtime';
import type { MiniAppDefinition } from '../config/catalog';
import type { MiniAppProps } from '../kit/types';

/** Entry URL currently registered for each remote, so a new version replaces the old one. */
const registered = new Map<string, string>();

/**
 * Registers the mini app's container at runtime and loads its "./App" module.
 * Re.Pack's Module Federation runtime plugin downloads the chunks through
 * ScriptManager and caches them on the device.
 */
export async function loadMiniApp(
  app: MiniAppDefinition,
  entryUrl: string,
): Promise<ComponentType<MiniAppProps>> {
  if (registered.get(app.remoteName) !== entryUrl) {
    registerRemotes([{ name: app.remoteName, entry: entryUrl }], {
      force: registered.has(app.remoteName),
    });
    registered.set(app.remoteName, entryUrl);
  }
  const mod = await loadRemote<{ default?: ComponentType<MiniAppProps> }>(
    `${app.remoteName}/${app.exposedModule.replace(/^\.\//, '')}`,
  );
  if (!mod?.default) {
    throw new Error(`${app.title} loaded, but its "./App" module has no default export.`);
  }
  return mod.default;
}
