import { TENANTS, type Tenant } from '../config/tenants';

/** Farms are built into the APK (src/config/tenants.ts). */
export async function loadTenants(): Promise<Tenant[]> {
  return TENANTS.map(t => ({ ...t, erpUrl: t.erpUrl.replace(/\/+$/, '') }));
}
