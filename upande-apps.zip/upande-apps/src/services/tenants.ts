import { MINI_APPS, type MiniAppId } from '../config/catalog';
import { TENANTS_URL } from '../config/env';
import { FALLBACK_TENANTS, type Tenant } from '../config/tenants';
import { fetchJson } from '../utils/net';
import { readJson, writeJson } from './storage';

const CACHE_KEY = 'shell:tenants';

function isTenant(t: any): t is Tenant {
  return (
    !!t &&
    typeof t.id === 'string' &&
    typeof t.name === 'string' &&
    typeof t.erpUrl === 'string' &&
    Array.isArray(t.miniApps)
  );
}

function clean(list: unknown): Tenant[] | null {
  if (!Array.isArray(list)) {
    return null;
  }
  const tenants = list.filter(isTenant).map(t => ({
    ...t,
    erpUrl: t.erpUrl.replace(/\/+$/, ''),
    // Ignore mini app ids this shell version doesn't know about.
    miniApps: t.miniApps.filter((id): id is MiniAppId => id in MINI_APPS),
  }));
  return tenants.length ? tenants : null;
}

/** Remote config, then the last cached copy, then the built-in fallback. */
export async function loadTenants(): Promise<Tenant[]> {
  try {
    const body = await fetchJson<{ tenants?: unknown }>(TENANTS_URL);
    const remote = clean(body.tenants);
    if (remote) {
      await writeJson(CACHE_KEY, remote);
      return remote;
    }
  } catch {
    // offline or config repo unreachable
  }
  return clean(await readJson(CACHE_KEY)) ?? FALLBACK_TENANTS;
}
