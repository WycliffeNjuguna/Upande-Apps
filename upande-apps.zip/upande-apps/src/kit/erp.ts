import { fetchJson, HttpError } from '../utils/net';
import type { ErpClient } from './types';

/**
 * Frappe REST client. Uses the session cookie set by /api/method/login,
 * which React Native's networking layer stores per site on both platforms.
 */
export function createErpClient(baseUrl: string, onUnauthorized: () => void): ErpClient {
  async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
    try {
      return await fetchJson<T>(`${baseUrl}${path}`, {
        credentials: 'include',
        ...init,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          ...(init.headers ?? {}),
        },
      });
    } catch (e) {
      if (e instanceof HttpError && (e.status === 401 || e.status === 403)) {
        onUnauthorized();
      }
      throw e;
    }
  }

  const enc = encodeURIComponent;

  return {
    async list(doctype, opts = {}) {
      const q = new URLSearchParams();
      if (opts.fields) q.set('fields', JSON.stringify(opts.fields));
      if (opts.filters) q.set('filters', JSON.stringify(opts.filters));
      if (opts.limit != null) q.set('limit_page_length', String(opts.limit));
      if (opts.orderBy) q.set('order_by', opts.orderBy);
      const r = await request<{ data: any[] }>(`/api/resource/${enc(doctype)}?${q.toString()}`);
      return r.data;
    },
    async get(doctype, name) {
      const r = await request<{ data: any }>(`/api/resource/${enc(doctype)}/${enc(name)}`);
      return r.data;
    },
    async insert(doctype, doc) {
      const r = await request<{ data: any }>(`/api/resource/${enc(doctype)}`, {
        method: 'POST',
        body: JSON.stringify(doc),
      });
      return r.data;
    },
    async update(doctype, name, changes) {
      const r = await request<{ data: any }>(`/api/resource/${enc(doctype)}/${enc(name)}`, {
        method: 'PUT',
        body: JSON.stringify(changes),
      });
      return r.data;
    },
    async call(method, args = {}) {
      const r = await request<{ message: any }>(`/api/method/${method}`, {
        method: 'POST',
        body: JSON.stringify(args),
      });
      return r.message;
    },
  };
}
