/**
 * The contract between Upande Apps (the shell) and every mini app.
 *
 * This file is the one thing all repos must agree on. Move it into
 * upande-mobile-kit and import it from there in the shell and in each mini
 * app, so a breaking change shows up as a kit major version bump.
 */

export interface KitTenant {
  id: string;
  name: string;
  erpUrl: string;
}

export interface KitUser {
  email: string;
  fullName: string;
}

export interface ErpClient {
  /** GET /api/resource/<doctype> with Frappe-style filters and fields. */
  list<T = Record<string, unknown>>(
    doctype: string,
    opts?: { fields?: string[]; filters?: unknown[]; limit?: number; orderBy?: string },
  ): Promise<T[]>;
  /** GET /api/resource/<doctype>/<name> */
  get<T = Record<string, unknown>>(doctype: string, name: string): Promise<T>;
  /** POST /api/resource/<doctype> */
  insert<T = Record<string, unknown>>(doctype: string, doc: Record<string, unknown>): Promise<T>;
  /** PUT /api/resource/<doctype>/<name> */
  update<T = Record<string, unknown>>(
    doctype: string,
    name: string,
    changes: Record<string, unknown>,
  ): Promise<T>;
  /** POST /api/method/<method>; returns `message`. */
  call<T = unknown>(method: string, args?: Record<string, unknown>): Promise<T>;
}

export interface UpandeKit {
  /** Kit contract version. Bump the major when this interface breaks. */
  contractVersion: 1;
  shellVersion: string;
  tenant: KitTenant;
  user: KitUser;
  erp: ErpClient;
  /** Close the mini app and return to the Upande Apps home screen. */
  exit(): void;
  /** Sign the user out of every mini app. */
  signOut(): Promise<void>;
}

/** Props the shell passes to the default export of each mini app's "./App". */
export interface MiniAppProps {
  kit: UpandeKit;
}
