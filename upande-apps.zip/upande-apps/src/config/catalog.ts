import { RELEASE_BRANCH, RELEASE_ORG } from './env';

export type MiniAppId = 'production' | 'livestock' | 'scp';

export interface MiniAppDefinition {
  id: MiniAppId;
  title: string;
  description: string;
  /** Module Federation container name. Must match `name` in the mini app's rspack config. */
  remoteName: string;
  /** Module the mini app exposes. Must match a key in the mini app's `exposes`. */
  exposedModule: './App';
  /** Source repository, for reference. */
  sourceRepo: string;
  /** Used in the release repo name: upande-<slug>-<client>-releases */
  releaseSlug: string;
  accent: string;
}

export const MINI_APPS: Record<MiniAppId, MiniAppDefinition> = {
  production: {
    id: 'production',
    title: 'Production',
    description: 'Harvest, grading and packhouse records',
    remoteName: 'production',
    exposedModule: './App',
    sourceRepo: 'upandeltd/upande-production-mobile',
    releaseSlug: 'production',
    accent: '#2F7D4F',
  },
  livestock: {
    id: 'livestock',
    title: 'Livestock',
    description: 'Herd, health and feeding records',
    remoteName: 'livestock',
    exposedModule: './App',
    sourceRepo: 'upandeltd/upande-livestock-mobile',
    releaseSlug: 'livestock',
    accent: '#8A5A2B',
  },
  scp: {
    id: 'scp',
    title: 'Scouting',
    description: 'Pest and disease scouting in the field',
    remoteName: 'scp',
    exposedModule: './App',
    sourceRepo: 'upandeltd/upande-scp-mobile',
    releaseSlug: 'scp',
    accent: '#2D5F8A',
  },
};

/** e.g. upande-production-kaitet-releases (the pattern your repos already use). */
export function releaseRepo(app: MiniAppDefinition, tenantId: string): string {
  return `upande-${app.releaseSlug}-${tenantId}-releases`;
}

/** Base URL that relative paths inside a release manifest are resolved against. */
export function releaseBaseUrl(app: MiniAppDefinition, tenantId: string): string {
  return `https://raw.githubusercontent.com/${RELEASE_ORG}/${releaseRepo(app, tenantId)}/${RELEASE_BRANCH}/`;
}
