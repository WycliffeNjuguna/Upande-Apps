export type MiniAppId = 'production' | 'livestock' | 'scp';

export interface MiniAppDefinition {
  id: MiniAppId;
  title: string;
  description: string;
  accent: string;
}

/** The mini apps compiled into Upande Apps. Code comes from miniapps/<id> at build time. */
export const MINI_APPS: Record<MiniAppId, MiniAppDefinition> = {
  production: {
    id: 'production',
    title: 'Production',
    description: 'Harvest, grading and packhouse records',
    accent: '#2F7D4F',
  },
  livestock: {
    id: 'livestock',
    title: 'Livestock',
    description: 'Herd, health and feeding records',
    accent: '#8A5A2B',
  },
  scp: {
    id: 'scp',
    title: 'Scouting',
    description: 'Pest and disease scouting in the field',
    accent: '#2D5F8A',
  },
};
