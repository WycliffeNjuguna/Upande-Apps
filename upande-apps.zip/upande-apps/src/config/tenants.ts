import type { MiniAppId } from './catalog';

export interface Tenant {
  id: string;
  name: string;
  /** The farm's Frappe / ERPNext site. */
  erpUrl: string;
  miniApps: MiniAppId[];
}

/**
 * Built-in fallback, used only when tenants.json can't be fetched and nothing
 * is cached yet. Mirrors today's client branches:
 *   Production: mutara, marginpar, kaitet
 *   Livestock:  kaitet, mutara
 *   SCP:        altura, kaitet, mutara, mona
 *
 * TODO: confirm each erpUrl is the live site, and fill in the empty ones.
 */
export const FALLBACK_TENANTS: Tenant[] = [
  {
    id: 'kaitet',
    name: 'Kaitet',
    erpUrl: 'https://upande-kaitet2.c.frappe.cloud',
    miniApps: ['production', 'livestock', 'scp'],
  },
  {
    id: 'mutara',
    name: 'Mutara',
    erpUrl: '',
    miniApps: ['production', 'livestock', 'scp'],
  },
  {
    id: 'marginpar',
    name: 'Marginpar',
    erpUrl: 'https://marginpar.frappe.cloud',
    miniApps: ['production'],
  },
  {
    id: 'altura',
    name: 'Altura',
    erpUrl: '',
    miniApps: ['scp'],
  },
  {
    id: 'mona',
    name: 'Mona Flowers',
    erpUrl: 'https://mona-flowers.upande.com',
    miniApps: ['scp'],
  },
];
