import type { MiniAppId } from './catalog';

export interface Tenant {
  id: string;
  name: string;
  /** The farm's Frappe / ERPNext site. */
  erpUrl: string;
  miniApps: MiniAppId[];
}

/**
 * Farms and the mini apps each one sees. Ships inside the APK, so changing
 * this needs a new build. Mirrors today's client branches:
 *   Production: mutara, marginpar, kaitet
 *   Livestock:  kaitet, mutara
 *   SCP:        altura, kaitet, mutara, mona
 *
 * TODO: confirm each erpUrl is the live site, and fill in the empty ones.
 */
export const TENANTS: Tenant[] = [
  {
    id: 'kaitet',
    name: 'Kaitet',
    erpUrl: 'https://upande-kaitet2.c.frappe.cloud',
    miniApps: ['production', 'livestock', 'scp'],
  },
  {
    id: 'mutara',
    name: 'Mutara',
    erpUrl: '',
    miniApps: ['production', 'livestock', 'scp'],
  },
  {
    id: 'marginpar',
    name: 'Marginpar',
    erpUrl: 'https://marginpar.frappe.cloud',
    miniApps: ['production'],
  },
  {
    id: 'altura',
    name: 'Altura',
    erpUrl: '',
    miniApps: ['scp'],
  },
  {
    id: 'mona',
    name: 'Mona Flowers',
    erpUrl: 'https://mona-flowers.upande.com',
    miniApps: ['scp'],
  },
];
