/** Upande Apps version. Keep in step with package.json "version". */
export const SHELL_VERSION = '1.0.0';

/** Network timeout for ERP requests, in milliseconds. */
export const REQUEST_TIMEOUT_MS = 15_000;
