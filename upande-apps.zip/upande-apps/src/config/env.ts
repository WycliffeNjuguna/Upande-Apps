/**
 * Shell-wide settings. Keep SHELL_VERSION in step with package.json "version":
 * mini app manifests use it to say which shell they need (minShellVersion).
 */
export const SHELL_VERSION = '1.0.0';

/** GitHub org that owns the mini app release repos. */
export const RELEASE_ORG = 'upandeltd';

/** Branch the release repos publish from. */
export const RELEASE_BRANCH = 'main';

/**
 * Where the shell reads which farms exist and which mini apps each one gets.
 * Editing this file (no app release needed) is how you onboard a new client
 * or give an existing client another mini app. If it can't be reached, the
 * shell falls back to the last copy it saw, then to src/config/tenants.ts.
 */
export const TENANTS_URL = `https://raw.githubusercontent.com/${RELEASE_ORG}/upande-apps-config/${RELEASE_BRANCH}/tenants.json`;

/** Network timeout for manifest and config requests, in milliseconds. */
export const REQUEST_TIMEOUT_MS = 10_000;
