declare module '@miniapps/*' {
  import type { ComponentType } from 'react';
  import type { MiniAppProps } from '../kit/types';
  const MiniApp: ComponentType<MiniAppProps>;
  export default MiniApp;
}
