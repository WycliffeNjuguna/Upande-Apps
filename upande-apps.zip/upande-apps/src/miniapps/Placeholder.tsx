import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Button } from '../components/Button';
import type { MiniAppProps } from '../kit/types';
import { colors, space, type } from '../theme';

/** Shown when a mini app's repo wasn't cloned into miniapps/<id> for this build. */
export default function Placeholder({ kit }: MiniAppProps) {
  return (
    <View style={styles.root}>
      <Text style={styles.title}>Not in this build</Text>
      <Text style={styles.body}>
        This app’s code wasn’t included when this copy of Upande Apps was built. Ask Upande to rebuild with it.
      </Text>
      <View style={styles.action}>
        <Button label="Back to apps" variant="quiet" onPress={kit.exit} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: space.lg, backgroundColor: colors.ground },
  title: { ...type.title, color: colors.ink, textAlign: 'center' },
  body: { ...type.body, color: colors.inkMuted, textAlign: 'center', marginTop: space.sm, maxWidth: 420 },
  action: { marginTop: space.lg, alignSelf: 'stretch', maxWidth: 420, width: '100%' },
});
