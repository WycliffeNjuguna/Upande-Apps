import type { ComponentType } from 'react';
import Livestock from '@miniapps/livestock';
import Production from '@miniapps/production';
import Scp from '@miniapps/scp';
import type { MiniAppId } from '../config/catalog';
import type { MiniAppProps } from '../kit/types';

/** Every mini app is compiled into the APK; see rspack.config.mjs for how each is found. */
export const MINI_APP_COMPONENTS: Record<MiniAppId, ComponentType<MiniAppProps>> = {
  production: Production,
  livestock: Livestock,
  scp: Scp,
};
