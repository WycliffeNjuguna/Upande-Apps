/** Shell palette: greenhouse greens on a pale sage ground. Mini apps bring their own accent. */
export const colors = {
  ground: '#EEF2EC',
  surface: '#FFFFFF',
  ink: '#16332A',
  inkMuted: '#5A6B61',
  line: '#D3DCD2',
  canopy: '#1E4A3A',
  onCanopy: '#E7F0EA',
  danger: '#A8261B',
  dangerTint: '#FBEAE8',
  notice: '#7A5A12',
  noticeTint: '#FBF2DC',
};

export const space = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };

export const type = {
  display: { fontSize: 30, lineHeight: 36, fontWeight: '700' as const, letterSpacing: -0.5 },
  title: { fontSize: 20, lineHeight: 26, fontWeight: '600' as const },
  body: { fontSize: 16, lineHeight: 23, fontWeight: '400' as const },
  small: { fontSize: 13, lineHeight: 18, fontWeight: '400' as const },
  label: { fontSize: 14, lineHeight: 18, fontWeight: '600' as const },
};
