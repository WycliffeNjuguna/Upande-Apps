import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, StatusBar, StyleSheet, View } from 'react-native';
import { initialWindowMetrics, SafeAreaProvider } from 'react-native-safe-area-context';
import type { MiniAppDefinition } from './config/catalog';
import { SHELL_VERSION } from './config/env';
import type { Tenant } from './config/tenants';
import { createErpClient } from './kit/erp';
import type { UpandeKit } from './kit/types';
import { restoreSession, signOut, type Session } from './services/auth';
import type { ResolvedRelease } from './services/releases';
import { loadTenants } from './services/tenants';
import { LauncherScreen } from './screens/LauncherScreen';
import { MiniAppHost } from './screens/MiniAppHost';
import { SignInScreen } from './screens/SignInScreen';
import { colors } from './theme';

type Open = { app: MiniAppDefinition; release: ResolvedRelease } | null;

export default function App() {
  const [booting, setBooting] = useState(true);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [session, setSession] = useState<Session | null>(null);
  const [open, setOpen] = useState<Open>(null);

  useEffect(() => {
    (async () => {
      const list = await loadTenants();
      setTenants(list);
      setSession(await restoreSession(list));
      setBooting(false);
    })();
  }, []);

  const tenant = session ? tenants.find(t => t.id === session.tenantId) : undefined;

  const handleSignOut = useCallback(async () => {
    setOpen(null);
    await signOut(tenant);
    setSession(null);
  }, [tenant]);

  const exitMiniApp = useCallback(() => setOpen(null), []);

  const kit = useMemo<UpandeKit | null>(() => {
    if (!session || !tenant) {
      return null;
    }
    return {
      contractVersion: 1,
      shellVersion: SHELL_VERSION,
      tenant: { id: tenant.id, name: tenant.name, erpUrl: tenant.erpUrl },
      user: session.user,
      erp: createErpClient(tenant.erpUrl, () => setSession(null)),
      exit: exitMiniApp,
      signOut: handleSignOut,
    };
  }, [session, tenant, exitMiniApp, handleSignOut]);

  let screen: React.ReactNode;
  if (booting) {
    screen = (
      <View style={styles.boot}>
        <ActivityIndicator size="large" color={colors.onCanopy} />
      </View>
    );
  } else if (!session || !tenant || !kit) {
    screen = <SignInScreen tenants={tenants} onSignedIn={setSession} />;
  } else if (open) {
    screen = (
      <MiniAppHost
        key={`${open.app.id}@${open.release.version}`}
        app={open.app}
        tenant={tenant}
        release={open.release}
        kit={kit}
        onExit={exitMiniApp}
      />
    );
  } else {
    screen = (
      <LauncherScreen
        tenant={tenant}
        user={session.user}
        onOpen={(app, release) => setOpen({ app, release })}
        onSignOut={handleSignOut}
      />
    );
  }

  return (
    <SafeAreaProvider initialMetrics={initialWindowMetrics}>
      <StatusBar barStyle={booting || (session && !open) ? 'light-content' : 'dark-content'} />
      {screen}
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  boot: { flex: 1, backgroundColor: colors.canopy, alignItems: 'center', justifyContent: 'center' },
});
