import React, { useCallback, useEffect, useState, type ComponentType } from 'react';
import { ActivityIndicator, BackHandler, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button } from '../components/Button';
import { ErrorBoundary } from '../components/ErrorBoundary';
import type { MiniAppDefinition } from '../config/catalog';
import type { Tenant } from '../config/tenants';
import type { MiniAppProps, UpandeKit } from '../kit/types';
import { loadMiniApp } from '../services/federation';
import { rememberGoodRelease, type ResolvedRelease } from '../services/releases';
import { colors, space, type } from '../theme';

interface Props {
  app: MiniAppDefinition;
  tenant: Tenant;
  release: ResolvedRelease;
  kit: UpandeKit;
  onExit: () => void;
}

type Phase =
  | { state: 'loading' }
  | { state: 'ready'; Component: ComponentType<MiniAppProps> }
  | { state: 'failed'; message: string };

export function MiniAppHost({ app, tenant, release, kit, onExit }: Props) {
  const [phase, setPhase] = useState<Phase>({ state: 'loading' });

  const load = useCallback(async () => {
    setPhase({ state: 'loading' });
    try {
      const Component = await loadMiniApp(app, release.entryUrl);
      await rememberGoodRelease(app, tenant, release);
      setPhase({ state: 'ready', Component });
    } catch (e) {
      console.warn(`[${app.id}] failed to load ${release.entryUrl}`, e);
      setPhase({
        state: 'failed',
        message: `${app.title} ${release.version} didn’t download. Check your connection, then try again.`,
      });
    }
  }, [app, tenant, release]);

  useEffect(() => {
    load();
  }, [load]);

  // While the shell owns the screen (loading or error), Android back returns home.
  // Once the mini app is showing, it handles back itself and calls kit.exit().
  useEffect(() => {
    if (phase.state === 'ready') {
      return;
    }
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onExit();
      return true;
    });
    return () => sub.remove();
  }, [phase.state, onExit]);

  if (phase.state === 'loading') {
    return (
      <Centered>
        <ActivityIndicator size="large" color={app.accent} />
        <Text style={styles.title}>Opening {app.title}</Text>
        <Text style={styles.body}>Version {release.version}</Text>
      </Centered>
    );
  }

  if (phase.state === 'failed') {
    return <Problem title={`Couldn’t open ${app.title}`} message={phase.message} onRetry={load} onExit={onExit} />;
  }

  const { Component } = phase;
  return (
    <ErrorBoundary
      fallback={(error, reset) => (
        <Problem
          title={`${app.title} stopped working`}
          message={`Your other apps are unaffected. Details: ${error.message}`}
          onRetry={reset}
          onExit={onExit}
        />
      )}>
      <Component kit={kit} />
    </ErrorBoundary>
  );
}

function Centered({ children }: { children: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.centered, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>{children}</View>
  );
}

function Problem(props: { title: string; message: string; onRetry: () => void; onExit: () => void }) {
  return (
    <Centered>
      <Text style={styles.title}>{props.title}</Text>
      <Text style={styles.body}>{props.message}</Text>
      <View style={styles.actions}>
        <Button label="Try again" onPress={props.onRetry} />
        <Button label="Back to apps" variant="quiet" onPress={props.onExit} />
      </View>
    </Centered>
  );
}

const styles = StyleSheet.create({
  centered: {
    flex: 1,
    backgroundColor: colors.ground,
    alignItems: 'center',
    justifyContent: 'center',
    padding: space.lg,
    gap: space.sm,
  },
  title: { ...type.title, color: colors.ink, textAlign: 'center', marginTop: space.md },
  body: { ...type.body, color: colors.inkMuted, textAlign: 'center', maxWidth: 420 },
  actions: { marginTop: space.lg, gap: space.sm, alignSelf: 'stretch', maxWidth: 420, width: '100%', alignItems: 'stretch' },
});
