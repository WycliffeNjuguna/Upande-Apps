import React, { useEffect } from 'react';
import { BackHandler, StyleSheet, Text, View } from 'react-native';
import { Button } from '../components/Button';
import { ErrorBoundary } from '../components/ErrorBoundary';
import type { MiniAppDefinition } from '../config/catalog';
import type { UpandeKit } from '../kit/types';
import { MINI_APP_COMPONENTS } from '../miniapps/registry';
import { colors, space, type } from '../theme';

interface Props {
  app: MiniAppDefinition;
  kit: UpandeKit;
  onExit: () => void;
}

/**
 * Registers the "back to Upande Apps" handler. It is rendered before the
 * mini app, so it registers first and therefore runs last: the mini app's
 * own navigation gets the back press first, and only when it has nothing
 * left to go back to does the user return to the home screen.
 */
function BackToHome({ onExit }: { onExit: () => void }) {
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onExit();
      return true;
    });
    return () => sub.remove();
  }, [onExit]);
  return null;
}

export function MiniAppHost({ app, kit, onExit }: Props) {
  const Component = MINI_APP_COMPONENTS[app.id];
  return (
    <>
      <BackToHome onExit={onExit} />
      <ErrorBoundary
        fallback={(error, reset) => (
          <View style={styles.centered}>
            <Text style={styles.title}>{app.title} stopped working</Text>
            <Text style={styles.body}>Your other apps are unaffected. Details: {error.message}</Text>
            <View style={styles.actions}>
              <Button label="Try again" onPress={reset} />
              <Button label="Back to apps" variant="quiet" onPress={onExit} />
            </View>
          </View>
        )}>
        <Component kit={kit} />
      </ErrorBoundary>
    </>
  );
}

const styles = StyleSheet.create({
  centered: {
    flex: 1,
    backgroundColor: colors.ground,
    alignItems: 'center',
    justifyContent: 'center',
    padding: space.lg,
    gap: space.sm,
  },
  title: { ...type.title, color: colors.ink, textAlign: 'center' },
  body: { ...type.body, color: colors.inkMuted, textAlign: 'center', maxWidth: 420 },
  actions: { marginTop: space.lg, gap: space.sm, alignSelf: 'stretch', maxWidth: 420, width: '100%' },
});
