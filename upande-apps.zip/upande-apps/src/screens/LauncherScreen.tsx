import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MINI_APPS, type MiniAppDefinition } from '../config/catalog';
import { SHELL_VERSION } from '../config/env';
import type { Tenant } from '../config/tenants';
import type { KitUser } from '../kit/types';
import { colors, space, type } from '../theme';

interface Props {
  tenant: Tenant;
  user: KitUser;
  onOpen: (app: MiniAppDefinition) => void;
  onSignOut: () => void;
}

export function LauncherScreen({ tenant, user, onOpen, onSignOut }: Props) {
  const insets = useSafeAreaInsets();
  const apps = tenant.miniApps.map(id => MINI_APPS[id]);
  const firstName = user.fullName.split(' ')[0];

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + space.lg }]}>
        <Text style={styles.farm}>{tenant.name}</Text>
        <Text style={styles.greeting}>Habari, {firstName}</Text>
      </View>

      <ScrollView contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + space.xl }]}>
        {apps.length === 0 ? (
          <Text style={styles.empty}>
            No apps are switched on for {tenant.name} yet. Ask Upande support to add the ones your team uses.
          </Text>
        ) : null}

        {apps.map(app => (
          <Pressable
            key={app.id}
            accessibilityRole="button"
            accessibilityLabel={`Open ${app.title}`}
            onPress={() => onOpen(app)}
            style={({ pressed }) => [styles.tile, pressed && styles.tilePressed]}>
            <View style={[styles.band, { backgroundColor: app.accent }]} />
            <View style={styles.tileBody}>
              <Text style={styles.tileTitle}>{app.title}</Text>
              <Text style={styles.tileDesc}>{app.description}</Text>
            </View>
          </Pressable>
        ))}

        <View style={styles.footer}>
          <Pressable accessibilityRole="button" onPress={onSignOut} hitSlop={12}>
            <Text style={styles.signOut}>Sign out</Text>
          </Pressable>
          <Text style={styles.meta}>
            Signed in as {user.email}. Upande Apps {SHELL_VERSION}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.ground },
  header: {
    backgroundColor: colors.canopy,
    paddingHorizontal: space.lg,
    paddingBottom: space.xl,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  farm: { ...type.label, color: colors.onCanopy, opacity: 0.8 },
  greeting: { ...type.display, color: colors.onCanopy, marginTop: space.xs },
  list: { padding: space.lg, gap: space.md, maxWidth: 640, width: '100%', alignSelf: 'center' },
  empty: { ...type.body, color: colors.inkMuted },
  tile: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.line,
  },
  tilePressed: { opacity: 0.9 },
  band: { width: 10 },
  tileBody: { flex: 1, padding: space.md, paddingVertical: space.lg },
  tileTitle: { ...type.title, color: colors.ink },
  tileDesc: { ...type.body, color: colors.inkMuted, marginTop: 2 },
  footer: { marginTop: space.lg, alignItems: 'center', gap: space.sm },
  signOut: { ...type.label, color: colors.canopy, fontSize: 16 },
  meta: { ...type.small, color: colors.inkMuted, textAlign: 'center' },
});
