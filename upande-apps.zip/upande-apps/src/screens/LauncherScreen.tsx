import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MINI_APPS, type MiniAppDefinition, type MiniAppId } from '../config/catalog';
import { SHELL_VERSION } from '../config/env';
import type { Tenant } from '../config/tenants';
import type { KitUser } from '../kit/types';
import { ReleaseError, resolveRelease, type ResolvedRelease } from '../services/releases';
import { colors, space, type } from '../theme';

type Status =
  | { state: 'checking' }
  | { state: 'ready'; release: ResolvedRelease }
  | { state: 'blocked'; message: string };

interface Props {
  tenant: Tenant;
  user: KitUser;
  onOpen: (app: MiniAppDefinition, release: ResolvedRelease) => void;
  onSignOut: () => void;
}

export function LauncherScreen({ tenant, user, onOpen, onSignOut }: Props) {
  const insets = useSafeAreaInsets();
  const apps = tenant.miniApps.map(id => MINI_APPS[id]);
  const [status, setStatus] = useState<Partial<Record<MiniAppId, Status>>>({});
  const [refreshing, setRefreshing] = useState(false);

  const check = useCallback(async () => {
    setStatus(Object.fromEntries(apps.map(a => [a.id, { state: 'checking' }])));
    await Promise.all(
      apps.map(async app => {
        let next: Status;
        try {
          next = { state: 'ready', release: await resolveRelease(app, tenant, user.email) };
        } catch (e) {
          next = {
            state: 'blocked',
            message:
              e instanceof ReleaseError && e.problem.kind === 'needs-shell-update'
                ? `Update Upande Apps from the store to open this (needs ${e.problem.required}).`
                : e instanceof Error
                ? e.message
                : 'Not available right now.',
          };
        }
        setStatus(s => ({ ...s, [app.id]: next }));
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenant.id, user.email]);

  useEffect(() => {
    check();
  }, [check]);

  const refresh = async () => {
    setRefreshing(true);
    await check();
    setRefreshing(false);
  };

  const firstName = user.fullName.split(' ')[0];

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + space.lg }]}>
        <Text style={styles.farm}>{tenant.name}</Text>
        <Text style={styles.greeting}>Habari, {firstName}</Text>
      </View>

      <ScrollView
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + space.xl }]}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}>
        {apps.length === 0 ? (
          <Text style={styles.empty}>
            No apps are switched on for {tenant.name} yet. Ask Upande support to add the ones your team uses.
          </Text>
        ) : null}

        {apps.map(app => {
          const s = status[app.id] ?? { state: 'checking' };
          const canOpen = s.state === 'ready';
          return (
            <Pressable
              key={app.id}
              accessibilityRole="button"
              accessibilityLabel={`Open ${app.title}`}
              accessibilityState={{ disabled: !canOpen }}
              disabled={!canOpen}
              onPress={() => canOpen && onOpen(app, s.release)}
              style={({ pressed }) => [styles.tile, pressed && styles.tilePressed]}>
              <View style={[styles.band, { backgroundColor: app.accent }]} />
              <View style={styles.tileBody}>
                <Text style={styles.tileTitle}>{app.title}</Text>
                <Text style={styles.tileDesc}>{app.description}</Text>
                <StatusLine status={s} />
              </View>
            </Pressable>
          );
        })}

        <View style={styles.footer}>
          <Pressable accessibilityRole="button" onPress={onSignOut} hitSlop={12}>
            <Text style={styles.signOut}>Sign out</Text>
          </Pressable>
          <Text style={styles.meta}>
            Signed in as {user.email}. Upande Apps {SHELL_VERSION}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

function StatusLine({ status }: { status: Status }) {
  if (status.state === 'checking') {
    return <Text style={styles.status}>Checking for updates…</Text>;
  }
  if (status.state === 'blocked') {
    return <Text style={[styles.status, styles.blocked]}>{status.message}</Text>;
  }
  const { version, source } = status.release;
  return (
    <Text style={styles.status}>
      {source === 'cache' ? `Offline, using saved version ${version}` : `Version ${version}`}
    </Text>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.ground },
  header: {
    backgroundColor: colors.canopy,
    paddingHorizontal: space.lg,
    paddingBottom: space.xl,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  farm: { ...type.label, color: colors.onCanopy, opacity: 0.8 },
  greeting: { ...type.display, color: colors.onCanopy, marginTop: space.xs },
  list: { padding: space.lg, gap: space.md, maxWidth: 640, width: '100%', alignSelf: 'center' },
  empty: { ...type.body, color: colors.inkMuted },
  tile: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.line,
  },
  tilePressed: { opacity: 0.9 },
  band: { width: 10 },
  tileBody: { flex: 1, padding: space.md, paddingVertical: space.md + 2 },
  tileTitle: { ...type.title, color: colors.ink },
  tileDesc: { ...type.body, color: colors.inkMuted, marginTop: 2 },
  status: { ...type.small, color: colors.inkMuted, marginTop: space.sm },
  blocked: {
    color: colors.notice,
    backgroundColor: colors.noticeTint,
    padding: space.sm,
    borderRadius: 8,
    overflow: 'hidden',
  },
  footer: { marginTop: space.lg, alignItems: 'center', gap: space.sm },
  signOut: { ...type.label, color: colors.canopy, fontSize: 16 },
  meta: { ...type.small, color: colors.inkMuted, textAlign: 'center' },
});
