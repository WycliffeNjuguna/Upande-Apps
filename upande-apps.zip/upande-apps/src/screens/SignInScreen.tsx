import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button } from '../components/Button';
import type { Tenant } from '../config/tenants';
import { signIn, SignInError, type Session } from '../services/auth';
import { colors, space, type } from '../theme';

interface Props {
  tenants: Tenant[];
  onSignedIn: (session: Session) => void;
}

export function SignInScreen({ tenants, onSignedIn }: Props) {
  const insets = useSafeAreaInsets();
  const [tenantId, setTenantId] = useState<string | null>(tenants.length === 1 ? tenants[0].id : null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const tenant = tenants.find(t => t.id === tenantId);
  const ready = !!tenant && email.trim().length > 0 && password.length > 0;

  async function submit() {
    if (!tenant) {
      setError('Choose your farm first.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      onSignedIn(await signIn(tenant, email, password));
    } catch (e) {
      setError(e instanceof SignInError ? e.message : 'Sign in didn’t work. Try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        style={styles.flex}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + space.xl, paddingBottom: insets.bottom + space.xl }]}
        keyboardShouldPersistTaps="handled">
        <Text style={styles.brand}>Upande Apps</Text>
        <Text style={styles.lede}>Sign in with your farm’s ERP account.</Text>

        <Text style={styles.label}>Farm</Text>
        <View style={styles.farms} accessibilityRole="radiogroup">
          {tenants.map(t => {
            const selected = t.id === tenantId;
            return (
              <Pressable
                key={t.id}
                accessibilityRole="radio"
                accessibilityState={{ selected }}
                onPress={() => {
                  setTenantId(t.id);
                  setError(null);
                }}
                style={[styles.farm, selected && styles.farmSelected]}>
                <View style={[styles.dot, selected && styles.dotSelected]} />
                <Text style={[styles.farmName, selected && styles.farmNameSelected]}>{t.name}</Text>
              </Pressable>
            );
          })}
        </View>

        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={v => {
            setEmail(v);
            setError(null);
          }}
          autoCapitalize="none"
          autoComplete="email"
          keyboardType="email-address"
          textContentType="username"
          placeholder="you@farm.co.ke"
          placeholderTextColor={colors.inkMuted}
        />

        <Text style={styles.label}>Password</Text>
        <TextInput
          style={styles.input}
          value={password}
          onChangeText={v => {
            setPassword(v);
            setError(null);
          }}
          secureTextEntry
          autoComplete="password"
          textContentType="password"
          onSubmitEditing={ready ? submit : undefined}
          returnKeyType="go"
        />

        {error ? (
          <Text style={styles.error} accessibilityLiveRegion="polite">
            {error}
          </Text>
        ) : null}

        <View style={styles.action}>
          <Button label="Sign in" onPress={submit} busy={busy} disabled={!ready} />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.ground },
  content: { paddingHorizontal: space.lg, maxWidth: 520, width: '100%', alignSelf: 'center' },
  brand: { ...type.display, color: colors.canopy },
  lede: { ...type.body, color: colors.inkMuted, marginTop: space.xs, marginBottom: space.xl },
  label: { ...type.label, color: colors.ink, marginBottom: space.sm, marginTop: space.md },
  farms: { gap: space.sm },
  farm: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    paddingVertical: 14,
    paddingHorizontal: space.md,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.surface,
  },
  farmSelected: { borderColor: colors.canopy, borderWidth: 2, paddingHorizontal: space.md - 1, paddingVertical: 13 },
  dot: { width: 18, height: 18, borderRadius: 9, borderWidth: 2, borderColor: colors.line },
  dotSelected: { borderColor: colors.canopy, backgroundColor: colors.canopy },
  farmName: { ...type.body, color: colors.ink },
  farmNameSelected: { fontWeight: '600' },
  input: {
    ...type.body,
    color: colors.ink,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 10,
    paddingHorizontal: space.md,
    paddingVertical: 13,
  },
  error: {
    ...type.small,
    color: colors.danger,
    backgroundColor: colors.dangerTint,
    padding: space.md,
    borderRadius: 10,
    marginTop: space.lg,
  },
  action: { marginTop: space.xl },
});
